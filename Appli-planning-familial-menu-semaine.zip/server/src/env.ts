import "dotenv/config";

function required(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined) throw new Error(`Missing required env var ${name}`);
  return v;
}

export const env = {
  port: Number(process.env.PORT ?? 4000),
  jwtAccessSecret: required("JWT_ACCESS_SECRET", "dev-access-secret-change-me"),
  jwtRefreshSecret: required("JWT_REFRESH_SECRET", "dev-refresh-secret-change-me"),
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID ?? "",
    clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    redirectUri: process.env.GOOGLE_REDIRECT_URI ?? "",
  },
  microsoft: {
    clientId: process.env.MICROSOFT_CLIENT_ID ?? "",
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET ?? "",
    tenantId: process.env.MICROSOFT_TENANT_ID ?? "common",
    redirectUri: process.env.MICROSOFT_REDIRECT_URI ?? "",
  },
  // Transactional e-mail (password reset codes) via Brevo's HTTP API.
  brevo: {
    apiKey: process.env.BREVO_API_KEY ?? "",
    senderEmail: process.env.MAIL_FROM_EMAIL ?? "",
    senderName: process.env.MAIL_FROM_NAME ?? "Passerelle",
  },
  appDeepLink: process.env.APP_DEEP_LINK ?? "passerelle://calendar-connected",
};

export const isGoogleConfigured = () => !!(env.google.clientId && env.google.clientSecret && env.google.redirectUri);
export const isMicrosoftConfigured = () => !!(env.microsoft.clientId && env.microsoft.clientSecret && env.microsoft.redirectUri);
export const isMailConfigured = () => !!(env.brevo.apiKey && env.brevo.senderEmail);
